package atividade.fila;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeFilaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeFilaApplication.class, args);
	}

}
