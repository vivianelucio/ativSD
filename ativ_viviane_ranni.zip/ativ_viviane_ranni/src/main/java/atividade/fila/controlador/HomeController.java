package atividade.fila.controlador;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import atividade.fila.mensageria.Consumer;
import atividade.fila.mensageria.Producer;
import atividade.fila.modelo.Veiculo;
import atividade.fila.repositorio.RepositorioVeiculo;


@Controller
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	private RepositorioVeiculo repositorio;
	
	@Autowired
	private Producer producer;
	
	@Autowired
	private Consumer consumer;

	@GetMapping
	public String home(Model model) {
		consumer.consumir();
		List<Veiculo> veiculos = new ArrayList<Veiculo>();
		veiculos = repositorio.findAll();
		model.addAttribute("veiculos", veiculos);
		return "home";
	}
	
	@GetMapping("/adicionar")
	public String adicionar(Model model) {
		model.addAttribute("veiculo", new Veiculo());
		return "novo-veiculo";
	}
	
	@PostMapping("/adicionar")
	public String adicionarVeiculo(@ModelAttribute("veiculo") Veiculo veiculo) {
		veiculo.setDataPublicacao(new Date());
		producer.enviar(veiculo);
		//repositorio.save(veiculo);
		return "redirect:/home";
	}
}
