package atividade.fila.mensageria;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.stereotype.Component;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import atividade.fila.modelo.Veiculo;

@Component
public class Producer {

	private static final String url = ActiveMQConnection.DEFAULT_BROKER_URL;
	private static final String subject = "FILA_DE_MENSAGEM";

	public void enviar(Veiculo veiculo) {
			try {

				ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
				Connection connection = connectionFactory.createConnection();
				connection.start();

				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

				Destination destination = session.createQueue(subject);

				MessageProducer producer = session.createProducer(destination);

				XStream xstream = new XStream(new StaxDriver());

				TextMessage message = session.createTextMessage(xstream.toXML(veiculo));
				producer.send(message);
				connection.close();

			} catch (JMSException e) {
				System.out.println(e.getMessage());
			}

		}
}
