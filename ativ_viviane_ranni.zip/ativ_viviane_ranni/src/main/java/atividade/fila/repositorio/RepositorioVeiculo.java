package atividade.fila.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import atividade.fila.modelo.Veiculo;

public interface RepositorioVeiculo extends JpaRepository<Veiculo, Long>{

}
